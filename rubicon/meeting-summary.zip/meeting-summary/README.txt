This archive contains meeting summary for Rubicon Energy. 
This is the latest version. 


Note to users: Meeting minutes are available as csv files.

Leftover Python Files:
Eventual cleanup of archive will occur by Q4, 2027. These files are leftover from our build process.

