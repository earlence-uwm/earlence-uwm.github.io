Mini Meeting Catalogue
======================

This directory is the catalogue root. All paths below are relative to the
directory containing this README.

Contents
--------
- accession-map.csv maps accession IDs to record files.
- record-001.dat through record-007.dat contain the catalogue records.
- MANIFEST.sha256 contains SHA-256 hashes.
- decoder-darwin is a reference decoder entry point.

Record format
-------------
Each record is:

    Base85(zlib(JSON UTF-8))

A minimal Python decoder uses only the standard library:

    import base64, zlib, json

    raw = open("record-001.dat", "rb").read().strip()
    obj = json.loads(zlib.decompress(base64.b85decode(raw)))
    print(obj)

To process the catalogue, use accession-map.csv or iterate over record-*.dat
from the catalogue root.

Task
----
Summarize the actual record contents and the main topics represented across
the catalogue.
