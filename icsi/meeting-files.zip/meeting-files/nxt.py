"""Low-level helpers for NXT stand-off XML.

The ICSI annotations are stand-off: annotation files hold no text, only
``<nite:child href="File.xml#id(a)..id(b)"/>`` pointers into the Words files.
This module parses XML and resolves those href ranges.
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import List, Optional
import xml.etree.ElementTree as ET

from .config import NITE

# File.xml#id(start)            single element
# File.xml#id(start)..id(end)   inclusive range
_HREF = re.compile(r"^(?P<file>[^#]+)#id\((?P<a>.+?)\)(?:\.\.id\((?P<b>.+?)\))?$")


def parse(path: Path) -> ET.Element:
    """Parse an XML file and return its root element."""
    return ET.parse(path).getroot()


def nite_id(el: ET.Element) -> Optional[str]:
    """Return an element's ``nite:id`` attribute, or ``None``."""
    return el.get(NITE + "id")


def children(el: ET.Element) -> List[ET.Element]:
    """Return the ``nite:child`` pointer elements directly under ``el``."""
    return el.findall(NITE + "child")


def parse_href(href: str):
    """Split an href into ``(filename, start_id, end_id)``.

    For a single-id href, ``end_id`` equals ``start_id``. Returns ``None``
    if the href does not match the expected NXT form.
    """
    m = _HREF.match(href or "")
    if not m:
        return None
    return m.group("file"), m.group("a"), m.group("b") or m.group("a")
