"""Command-line entry point.

Examples::

    python -m src.cli            # full rebuild: CSV, batches, site zip
    python -m src.cli --no-site  # rebuild data only, skip the zip
    python -m src.cli --stats    # print stats for the existing CSV
    python -m src.cli --verify   # check every field round-trips
"""
from __future__ import annotations
import argparse

from . import pipeline, stats


def _print_stats(s: "stats.DatasetStats") -> None:
    print("  meetings            : %d" % s.meetings)
    print("  distinct speakers   : %d" % s.distinct_speakers)
    print("  attendees / meeting : %d-%d (avg %.1f)"
          % (s.attendees_min, s.attendees_max, s.attendees_avg))
    print("  transcript words    : %s" % format(s.transcript_words, ","))
    print("  summary words       : %s" % format(s.summary_words, ","))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Rebuild the ICSI subsampled dataset.")
    ap.add_argument("--no-site", action="store_true", help="skip building the site zip")
    ap.add_argument("--stats", action="store_true", help="print stats for existing CSV and exit")
    ap.add_argument("--verify", action="store_true", help="verify round-trip of existing CSV and exit")
    args = ap.parse_args(argv)

    if args.stats:
        _print_stats(stats.compute_stats())
        return 0
    if args.verify:
        ok = stats.verify_dataset()
        print("round-trip verification:", "OK" if ok else "FAILED")
        return 0 if ok else 1

    result = pipeline.run(build_site=not args.no_site)
    print("Rebuilt ICSI subsampled dataset")
    print("  CSV      : %s (%d rows)" % (result.csv_path, result.n_meetings))
    print("  batches  : %d files" % result.n_batches)
    if result.zip_path:
        print("  site zip : %s" % result.zip_path)
    print("  verified : %s" % ("OK" if result.verified else "FAILED"))
    _print_stats(result.stats)
    return 0 if result.verified else 1


if __name__ == "__main__":
    raise SystemExit(main())
