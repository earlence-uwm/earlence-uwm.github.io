"""Parse an abstractive summary file into labelled section text.

An ``*.abssumm.xml`` file groups sentences under four sections. We keep the
canonical order and emit each present section as an upper-cased ``[LABEL]``
block followed by its sentences.
"""
from __future__ import annotations
from pathlib import Path
from typing import List

from . import nxt
from .config import ABSSUMM_DIR, SUMMARY_SECTIONS


def summary_path(meeting: str) -> Path:
    return ABSSUMM_DIR / (meeting + ".abssumm.xml")


def render_summary(meeting: str) -> str:
    """Return the summary for ``meeting`` as labelled section blocks."""
    root = nxt.parse(summary_path(meeting))
    blocks: List[str] = []
    for section in SUMMARY_SECTIONS:
        sentences: List[str] = []
        for node in root.findall(section):
            for sent in node.findall("sentence"):
                text = "".join(sent.itertext()).strip()
                if text:
                    sentences.append(text)
        if sentences:
            blocks.append("[%s]\n%s" % (section.upper(), " ".join(sentences)))
    return "\n\n".join(blocks)


def meetings_with_summaries(abssumm_dir: Path = ABSSUMM_DIR) -> List[str]:
    """Return the sorted meeting ids that have an abstractive summary."""
    suffix = ".abssumm.xml"
    return sorted(p.name[: -len(suffix)] for p in abssumm_dir.glob("*" + suffix))
