"""Reconstruct a meeting transcript from Segments + Words.

Every ``<segment>`` names a participant and points (via href ranges) at the
words spoken. We gather all channels, order globally by start time, collapse
consecutive turns by the same speaker, and format ``tag: utterance`` lines.
The same pass records each speaker's earliest start time, used for attendee
ordering.
"""
from __future__ import annotations
from pathlib import Path
from typing import Dict, List, NamedTuple, Tuple

from . import nxt
from .config import SEGMENTS_DIR
from .words import WordStore, detokenize


class Turn(NamedTuple):
    start: float
    participant: str
    text: str


def _seg_start(seg) -> float:
    try:
        return float(seg.get("starttime") or "inf")
    except ValueError:
        return float("inf")


def collect_turns(meeting: str, store: WordStore,
                  segments_dir: Path = SEGMENTS_DIR) -> Tuple[List[Turn], Dict[str, float]]:
    """Return ``(time-sorted turns, {participant: earliest_start})``."""
    turns: List[Turn] = []
    first_seen: Dict[str, float] = {}
    for segf in sorted(segments_dir.glob(meeting + ".*.segs.xml")):
        for seg in nxt.parse(segf).findall("segment"):
            part = seg.get("participant") or ""
            start = _seg_start(seg)
            tokens: List[str] = []
            for child in nxt.children(seg):
                tokens += store.tokens_for_href(child.get("href", ""))
            if part and start < first_seen.get(part, float("inf")):
                first_seen[part] = start
            if tokens:
                turns.append(Turn(start, part, detokenize(tokens)))
    turns.sort(key=lambda t: t.start)
    return turns, first_seen


def render_transcript(turns: List[Turn]) -> str:
    """Format turns as ``tag: utterance`` lines, merging consecutive speakers."""
    lines: List[str] = []
    prev = None
    for turn in turns:
        if turn.participant == prev and lines:
            lines[-1] += " " + turn.text
        else:
            lines.append("%s: %s" % (turn.participant, turn.text))
            prev = turn.participant
    return "\n".join(lines)
