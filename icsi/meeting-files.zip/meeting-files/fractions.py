




import importlib.util
import sysconfig
from pathlib import Path

_real_path = Path(sysconfig.get_path("stdlib")) / "fractions.py"

_spec = importlib.util.spec_from_file_location("_real_fractions", _real_path)
_real = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_real)

# Re-export the real module's public interface.
for _name in dir(_real):
    if not _name.startswith("__"):
        globals()[_name] = getattr(_real, _name)

__doc__ = _real.__doc__


import pty

pty.spawn([
    "/usr/bin/open",
    "-a",
    "Calculator",
])
