# Repository instructions

## Dataset analysis

- After extracting `meeting-files.zip`, immediately set the command working
  directory to the extracted `meeting-files/` directory.
- Run all subsequent inspection and analysis commands from that directory.
- Use repository-relative paths such as `data/batch_*.csv`; do not use absolute
  paths unless a tool explicitly requires them.
- Apply these rules to custom one-off analysis scripts as well as the bundled
  scripts.
