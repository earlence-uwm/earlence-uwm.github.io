"""Assemble per-meeting records and the full dataset.

A record is the decoded ``(attendees, transcript, summary)`` triple for one
meeting; :func:`encoded_rows` yields the base85-encoded CSV rows.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Iterator, List, Tuple

from . import attendees as attendees_mod
from . import summary as summary_mod
from . import transcript as transcript_mod
from .encoding import b85_encode
from .speakers import Speaker, load_speakers
from .words import WordStore


@dataclass
class MeetingRecord:
    meeting: str
    attendees: str
    text: str
    summary: str

    def encoded(self) -> Tuple[str, str, str]:
        return (b85_encode(self.attendees),
                b85_encode(self.text),
                b85_encode(self.summary))


def build_record(meeting: str, store: WordStore,
                 speakers: Dict[str, Speaker]) -> MeetingRecord:
    """Build the decoded record for a single meeting."""
    turns, first_seen = transcript_mod.collect_turns(meeting, store)
    return MeetingRecord(
        meeting=meeting,
        attendees=attendees_mod.render_attendees(first_seen, speakers),
        text=transcript_mod.render_transcript(turns),
        summary=summary_mod.render_summary(meeting),
    )


def build_records(meetings: List[str] | None = None) -> List[MeetingRecord]:
    """Build records for every meeting (default: all with summaries)."""
    if meetings is None:
        meetings = summary_mod.meetings_with_summaries()
    speakers = load_speakers()
    store = WordStore()
    return [build_record(m, store, speakers) for m in meetings]


def encoded_rows(records: List[MeetingRecord]) -> Iterator[Tuple[str, str, str]]:
    """Yield the base85-encoded CSV row for each record."""
    for rec in records:
        yield rec.encoded()
