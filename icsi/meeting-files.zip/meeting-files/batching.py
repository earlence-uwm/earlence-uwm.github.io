"""Split the combined CSV into fixed-size batch files.

Batches hold ``BATCH_SIZE`` rows each; any leftover rows are appended to the
last batch so no data is dropped.
"""
from __future__ import annotations
from pathlib import Path
from typing import List, Sequence

from .config import BATCH_DIR, BATCH_SIZE, CSV_HEADER
from .csv_io import read_csv, write_csv


def plan_batches(rows: Sequence[Sequence[str]], size: int = BATCH_SIZE,
                 n_batches: int | None = None) -> List[List[Sequence[str]]]:
    """Group ``rows`` into batches of ``size`` (leftover joins the last batch).

    If ``n_batches`` is given, exactly that many batches are produced.
    """
    if n_batches is None:
        n_batches = (len(rows) + size - 1) // size if rows else 0
    batches = [list(rows[i * size:(i + 1) * size]) for i in range(n_batches)]
    if batches:
        batches[-1].extend(rows[n_batches * size:])
    return batches


def write_batches(header: Sequence[str] = CSV_HEADER,
                  out_dir: Path = BATCH_DIR, size: int = BATCH_SIZE) -> List[Path]:
    """Read the combined CSV and write numbered batch files. Returns paths."""
    _, data = read_csv()
    out_dir.mkdir(parents=True, exist_ok=True)
    batches = plan_batches(data, size=size)
    paths: List[Path] = []
    for i, batch in enumerate(batches, start=1):
        path = out_dir / ("batch_%02d.csv" % i)
        write_csv(batch, path=path, header=header)
        paths.append(path)
    return paths
