"""Compute descriptive statistics over the encoded dataset.

These are the figures shown on the site's stat strip; deriving them from the
CSV keeps the page honest if the dataset is ever regenerated.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List

from .csv_io import read_csv
from .encoding import b85_decode


@dataclass
class DatasetStats:
    meetings: int
    distinct_speakers: int
    attendees_min: int
    attendees_max: int
    attendees_avg: float
    transcript_words: int
    summary_words: int

    def as_dict(self) -> Dict[str, float]:
        return asdict(self)


def compute_stats(path: Path | None = None) -> DatasetStats:
    """Decode every field and compute dataset-level statistics."""
    _, data = read_csv() if path is None else read_csv(path)
    speakers = set()
    att_counts: List[int] = []
    transcript_words = 0
    summary_words = 0
    for att_b85, text_b85, summ_b85 in data:
        roster = [e for e in b85_decode(att_b85).split("; ") if e]
        att_counts.append(len(roster))
        for entry in roster:
            speakers.add(entry.split()[0])
        transcript_words += len(b85_decode(text_b85).split())
        summary_words += len(b85_decode(summ_b85).split())
    n = len(att_counts)
    return DatasetStats(
        meetings=len(data),
        distinct_speakers=len(speakers),
        attendees_min=min(att_counts) if att_counts else 0,
        attendees_max=max(att_counts) if att_counts else 0,
        attendees_avg=round(sum(att_counts) / n, 1) if n else 0.0,
        transcript_words=transcript_words,
        summary_words=summary_words,
    )


def verify_dataset(path: Path | None = None) -> bool:
    """Return ``True`` if every field decodes cleanly as UTF-8."""
    _, data = read_csv() if path is None else read_csv(path)
    for row in data:
        for field in row:
            try:
                b85_decode(field)
            except Exception:
                return False
    return True
