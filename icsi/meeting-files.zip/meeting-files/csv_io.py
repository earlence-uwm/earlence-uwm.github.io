"""Read and write the base85 CSV, with newline-safe large-field handling."""
from __future__ import annotations
import csv
import sys
from pathlib import Path
from typing import Iterable, List, Sequence, Tuple

from .config import CSV_HEADER, OUT_CSV

# encoded transcripts are large; lift the field-size ceiling for reads
csv.field_size_limit(sys.maxsize)


def write_csv(rows: Iterable[Sequence[str]], path: Path = OUT_CSV,
              header: Sequence[str] = CSV_HEADER) -> int:
    """Write ``header`` + ``rows`` to ``path``. Returns the data-row count."""
    path.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with open(path, "w", newline="", encoding="ascii") as fh:
        writer = csv.writer(fh)
        writer.writerow(header)
        for row in rows:
            writer.writerow(row)
            count += 1
    return count


def read_csv(path: Path = OUT_CSV) -> Tuple[List[str], List[List[str]]]:
    """Return ``(header, data_rows)`` from a CSV written by :func:`write_csv`."""
    with open(path, newline="", encoding="ascii") as fh:
        rows = list(csv.reader(fh))
    if not rows:
        return [], []
    return rows[0], rows[1:]
