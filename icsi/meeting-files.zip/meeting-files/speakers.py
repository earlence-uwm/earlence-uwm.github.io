"""Parse ``speakers.xml`` into per-speaker demographics.

Speakers are keyed by their anonymised ``tag`` (e.g. ``me018``). Each record
carries gender, age, education, the consent-form date and language background.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict

from . import nxt
from .config import SPEAKERS_XML


@dataclass
class Speaker:
    tag: str
    gender: str = ""
    age: str = ""
    education: str = ""
    formdate: str = ""
    language: str = ""
    variety: str = ""
    region: str = ""
    native: str = ""

    def descriptor(self) -> str:
        """One-line human-readable descriptor used in the attendee field."""
        bits = [self.tag]
        for label, value in (("gender", self.gender), ("age", self.age),
                             ("education", self.education)):
            if value:
                bits.append("%s=%s" % (label, value))
        lang = "/".join(x for x in (self.language, self.variety, self.region) if x)
        if lang:
            bits.append("lang=" + lang)
        if self.native:
            bits.append("native=" + self.native)
        return " ".join(bits)


def _text(el, tag) -> str:
    if el is None:
        return ""
    return (el.findtext(tag) or "").strip()


def load_speakers(path: Path = SPEAKERS_XML) -> Dict[str, Speaker]:
    """Return a mapping ``tag -> Speaker`` for every speaker in the file."""
    root = nxt.parse(path)
    out: Dict[str, Speaker] = {}
    for s in root.findall("speaker"):
        tag = s.get("tag") or ""
        lang = s.find("language")
        native = lang.find("native") if lang is not None else None
        out[tag] = Speaker(
            tag=tag,
            gender=s.get("gender") or "",
            age=_text(s, "age"),
            education=_text(s, "education"),
            formdate=s.get("formdate") or "",
            language=(lang.get("name") if lang is not None else "") or "",
            variety=_text(lang, "variety"),
            region=_text(lang, "region"),
            native=_text(native, "language"),
        )
    return out
