This archive contains meeting summary files for ICSI. 
This is the latest version. 


Note to users: Meeting minutes are available as csv files.


