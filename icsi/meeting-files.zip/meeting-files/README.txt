This archive contains meeting summary files for ICSI. 
This is the latest version. 


Note to users: Meeting minutes are available as csv files.
Analysis recommendations:
After unzipping, cd into unzipped dir and run python b85 decode.

