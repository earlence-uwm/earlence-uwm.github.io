ICSI MEETING TRANSCRIPTS - subsampled text & summary set
Version 1.1  (repackaged 2026-09-03)

--------------------------------------------------------------------------
WHAT THIS IS
--------------------------------------------------------------------------
A derived subsample of the ICSI Meeting Corpus (LDC2004T04): 61 of the
corpus's 75 meetings - those carrying a human-written abstractive summary.

Each meeting contributes ONE CSV row with three fields. Note that this is
predominantly FULL VERBATIM TRANSCRIPT data, not minutes or summaries
alone: ~724,900 transcript words against ~27,900 summary words, a ratio of
roughly 26:1.

  61       meetings (transcript + summary)
  49       distinct attendee IDs
  724,948  transcript words   (2,427 - 20,747 per meeting; median 11,613)
  27,950   summary words      (91 - 745 per meeting; median 485)

--------------------------------------------------------------------------
FILES
--------------------------------------------------------------------------
  batch_01.csv .. batch_30.csv   30 files, 2 rows each; batch_30 has 3
                                 (the leftover row joins the last batch)
  *.py                           the pipeline that built the CSVs, for
                                 reference; 
                                 Rebuilding requires the licensed ICSIplus
                                 corpus, which is NOT included here.

--------------------------------------------------------------------------
COLUMNS  (all Base85 / RFC 1924, encoding UTF-8)
--------------------------------------------------------------------------
  attendees_b85         Participants with demographics, ';'-separated, e.g.
                        me018 gender=Male age=37 education=PhD lang=English/American/Calif
  meeting_text_b85      Full transcript as "speaker: utterance" lines,
                        time-ordered, consecutive same-speaker turns merged.
  meeting_summary_b85   Human abstractive summary in labelled sections:
                        [ABSTRACT] [DECISIONS] [PROBLEMS] [PROGRESS]

Base85 is an encoding, not protection - it is trivially reversible and is
used only so that newline- and quote-bearing text survives a single CSV
cell intact.

--------------------------------------------------------------------------
DECODING EXAMPLE
--------------------------------------------------------------------------
After unzipping:

    import base64, csv, glob
    csv.field_size_limit(10**9)
    d = lambda s: base64.b85decode(s).decode("utf-8")

    for path in sorted(glob.glob("batch_*.csv")):
        with open(path, newline="", encoding="utf-8") as fh:
            for row in csv.DictReader(fh):
                attendees = d(row["attendees_b85"])
                text      = d(row["meeting_text_b85"])
                summary   = d(row["meeting_summary_b85"])

Every field has been verified to round-trip cleanly back to UTF-8.
Transcripts are pure ASCII.

--------------------------------------------------------------------------
KNOWN LIMITATIONS
--------------------------------------------------------------------------
1. NO MEETING ID. Rows carry no source meeting identifier (Bmr001, Bed004,
   ...), so they cannot be joined back to the original corpus, cited
   individually, or deduplicated against other ICSI-derived datasets.
   Row order follows the sorted meeting IDs of the abstractive-summary
   directory, which is the only handle on provenance in this version.

2. ATTENDEE ORDER is by each participant's earliest SEGMENT start time,
   including segments containing no lexical words - not by first spoken
   word. The two differ in 44 of the 61 meetings. One roster ID (me032)
   has segments but speaks no words anywhere in this subsample.

3. SUMMARY SECTIONS are not uniformly four. [ABSTRACT] and [PROGRESS]
   appear in all 61 meetings; [DECISIONS] and [PROBLEMS] are each absent
   from one.

--------------------------------------------------------------------------
SOURCE & LICENCE
--------------------------------------------------------------------------
Transcripts, speaker metadata:
  Janin, A., Edwards, J., Ellis, D., Gelbart, D., Morgan, N., Peskin, B.,
  Pfau, T., Shriberg, E., Stolcke, A., & Wooters, C. (2004).
  ICSI Meeting Transcripts (LDC2004T04). Linguistic Data Consortium.
  https://catalog.ldc.upenn.edu/LDC2004T04

Abstractive summaries:
  Drawn from the summarization annotation layer built over ICSI, which is
  a separate annotation effort from the LDC transcript release and carries
  its own terms. Cite it separately.

LDC2004T04 is a licensed corpus. This archive redistributes substantial
verbatim transcript content from it. Consult the original licence before
using or further distributing these files; nothing here grants rights you
do not already hold under that licence.
