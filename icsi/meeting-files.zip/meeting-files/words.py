"""Load Words files and turn word-id ranges into text.

Each Words file is an ordered list of elements; only ``<w>`` elements carry
lexical text. We keep the order so a ``#id(a)..id(b)`` range can be sliced,
and drop non-lexical events (pauses, vocal sounds, ...) from the output.
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from . import nxt
from .config import WORDS_DIR

# collapse the space a naive join leaves before trailing punctuation
_PUNCT = re.compile(r"\s+([,.;:!?%])")

# (ordered [(id, text|None)], id -> position)
WordFile = Tuple[List[Tuple[str, Optional[str]]], Dict[str, int]]


def load_word_file(path: Path) -> WordFile:
    """Parse one Words file into an ordered list and an id->index map."""
    items: List[Tuple[str, Optional[str]]] = []
    index: Dict[str, int] = {}
    for el in nxt.parse(path):
        wid = nxt.nite_id(el)
        if wid is None:
            continue
        tag = el.tag.split("}")[-1]
        text = (el.text or "").strip() if tag == "w" else None
        index[wid] = len(items)
        items.append((wid, text))
    return items, index


class WordStore:
    """Lazily loads and caches Words files, resolving href ranges to tokens."""

    def __init__(self, words_dir: Path = WORDS_DIR):
        self.words_dir = words_dir
        self._cache: Dict[str, WordFile] = {}

    def _get(self, filename: str) -> WordFile:
        if filename not in self._cache:
            path = self.words_dir / filename
            self._cache[filename] = load_word_file(path) if path.exists() else ([], {})
        return self._cache[filename]

    def tokens_for_href(self, href: str) -> List[str]:
        """Return the lexical tokens covered by a single href range."""
        parsed = nxt.parse_href(href)
        if parsed is None:
            return []
        filename, a, b = parsed
        items, index = self._get(filename)
        if a not in index or b not in index:
            return []
        return [t for _, t in items[index[a]: index[b] + 1] if t]


def detokenize(tokens: List[str]) -> str:
    """Join tokens with spaces, tightening spacing before punctuation."""
    return _PUNCT.sub(r"\1", " ".join(tokens)).strip()
