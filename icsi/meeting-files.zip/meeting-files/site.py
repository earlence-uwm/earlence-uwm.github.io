"""Bundle the download the single-page site serves.

Zips the combined CSV plus every batch file into ``site/meeting-files.zip``
(flat, no directory prefixes) so the page's one button serves current data.
"""
from __future__ import annotations
import zipfile
from pathlib import Path
from typing import List

from .config import BATCH_DIR, OUT_CSV, ZIP_PATH


def gather_files() -> List[Path]:
    """The files to include: combined CSV first, then batch_*.csv in order."""
    files = [OUT_CSV] if OUT_CSV.exists() else []
    files += sorted(BATCH_DIR.glob("batch_*.csv"))
    return files


def build_zip(zip_path: Path = ZIP_PATH) -> Path:
    """(Re)build the download zip. Returns its path."""
    files = gather_files()
    if not files:
        raise FileNotFoundError("no CSV files to bundle; run the pipeline first")
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in files:
            zf.write(f, arcname=f.name)   # flat: store by basename only
    return zip_path
