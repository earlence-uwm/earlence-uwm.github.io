"""Central configuration: filesystem layout and corpus constants.

All paths are derived from this file's location, so the package works
regardless of where the repository lives, as long as the ``src/`` folder
stays inside ``icsi/`` next to the ``ICSIplus/`` corpus directory.
"""
from __future__ import annotations
from pathlib import Path

# ---- filesystem layout -----------------------------------------------------
# src/ lives inside icsi/ ; the corpus and outputs are siblings of src/.
ICSI_DIR: Path = Path(__file__).resolve().parent.parent      # .../icsi
CORPUS_DIR: Path = ICSI_DIR / "ICSIplus"                     # NXT release root

WORDS_DIR: Path = CORPUS_DIR / "Words"
SEGMENTS_DIR: Path = CORPUS_DIR / "Segments"
SPEAKERS_XML: Path = CORPUS_DIR / "speakers.xml"
ABSSUMM_DIR: Path = CORPUS_DIR / "Contributions" / "Summarization" / "abstractive"

# ---- outputs ---------------------------------------------------------------
OUT_CSV: Path = ICSI_DIR / "icsi_meetings_b85.csv"
BATCH_DIR: Path = ICSI_DIR / "batches"
SITE_DIR: Path = ICSI_DIR / "site"
ZIP_PATH: Path = SITE_DIR / "meeting-files.zip"

BATCH_SIZE: int = 2
CSV_HEADER = ("attendees_b85", "meeting_text_b85", "meeting_summary_b85")

# ---- corpus constants ------------------------------------------------------
NITE_NS = "http://nite.sourceforge.net/"
NITE = "{%s}" % NITE_NS

# Word-file elements that carry an id but no lexical text.
NON_WORD_TAGS = frozenset({"vocalsound", "nonvocalsound", "disfmarker", "pause", "comment"})

# Ordered sections of an abstractive summary.
SUMMARY_SECTIONS = ("abstract", "decisions", "problems", "progress")
