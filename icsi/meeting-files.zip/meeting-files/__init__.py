"""Reproducible pipeline for the ICSI subsampled meeting dataset.

Rebuilds, from the ICSIplus NXT corpus, a CSV of
``(attendees, transcript, summary)`` triples with every field base85-encoded,
splits it into batches, and bundles the download served by the site.

Typical use::

    python -m src.cli            # run the whole pipeline
    python -m src.cli --stats    # just print dataset statistics
"""
__version__ = "1.0.0"
