"""Base85 (RFC 1924 / ``b85``) encode/decode for UTF-8 text.

Base85's alphabet contains no newline, comma or double-quote, so an encoded
field is safe to drop into a single CSV cell and round-trips unchanged.
"""
from __future__ import annotations
import base64


def b85_encode(text: str) -> str:
    """Encode UTF-8 ``text`` to an ASCII base85 string."""
    return base64.b85encode(text.encode("utf-8")).decode("ascii")


def b85_decode(token: str) -> str:
    """Decode a base85 string produced by :func:`b85_encode` back to text."""
    return base64.b85decode(token.encode("ascii")).decode("utf-8")


def verify_roundtrip(text: str) -> bool:
    """Return ``True`` if ``text`` survives an encode/decode round-trip."""
    try:
        return b85_decode(b85_encode(text)) == text
    except Exception:
        return False
