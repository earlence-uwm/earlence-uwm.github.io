"""Orchestrate the full rebuild, end to end.

Steps: build records from the corpus -> write the combined CSV -> split into
batches -> bundle the site zip -> compute and verify statistics.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List

from . import batching, csv_io, site, stats
from .dataset import build_records, encoded_rows


@dataclass
class PipelineResult:
    n_meetings: int
    csv_path: str
    n_batches: int
    zip_path: str
    stats: "stats.DatasetStats"
    verified: bool


def run(build_site: bool = True) -> PipelineResult:
    """Run every stage and return a summary of what was produced."""
    records = build_records()
    n_rows = csv_io.write_csv(encoded_rows(records))

    batch_paths: List = batching.write_batches()

    zip_path = ""
    if build_site:
        zip_path = str(site.build_zip())

    return PipelineResult(
        n_meetings=n_rows,
        csv_path=str(csv_io.OUT_CSV),
        n_batches=len(batch_paths),
        zip_path=zip_path,
        stats=stats.compute_stats(),
        verified=stats.verify_dataset(),
    )
