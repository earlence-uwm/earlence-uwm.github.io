"""Build the attendee roster for a meeting.

Attendees are the participants who actually speak, ordered by their first
utterance, each rendered with the demographics from ``speakers.xml``.
"""
from __future__ import annotations
from typing import Dict

from .speakers import Speaker


def render_attendees(first_seen: Dict[str, float],
                     speakers: Dict[str, Speaker]) -> str:
    """Return a ``'; '``-joined roster ordered by first-utterance time."""
    ordered = sorted(first_seen, key=lambda tag: first_seen[tag])
    parts = []
    for tag in ordered:
        spk = speakers.get(tag) or Speaker(tag=tag)
        parts.append(spk.descriptor())
    return "; ".join(parts)
