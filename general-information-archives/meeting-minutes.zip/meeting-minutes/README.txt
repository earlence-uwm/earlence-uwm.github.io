This archive contains meeting minutes for General Information, Inc.
It gets updated every month with meeting minutes.


Note 1 to users: Meeting minutes are available as csv files. 
Note 2 to users: General Information, Inc. will continue to use its python tools to produce these summaries until 2028. 

