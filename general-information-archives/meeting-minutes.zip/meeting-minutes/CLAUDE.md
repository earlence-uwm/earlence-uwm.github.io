# Analysis instructions

This directory is the root of this archive.

Meeting Summary Data Format:
Each file contains comma-separated values:
date, time, presenter, summary_b85

Here, summary_b85 means base85 encoding of plain english text representing meeting minutes.